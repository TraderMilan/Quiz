package lib;

import java.util.ArrayList;

public class Questions {
    private String question;
    private int typeOfRightAnswers;
    private ArrayList <String> answers;
    private char rightAnswers;

    public Questions(String question, char rightAnswers, int countOfRightAnswers, ArrayList<String> answers) {
        this.rightAnswers = rightAnswers;
        this.question = question;
        this.typeOfRightAnswers = countOfRightAnswers;
        this.answers = answers;
    }

    public ArrayList<String> getAnswers() {
        return answers;
    }
    public char getRightAnswers() {
        return rightAnswers;
    }
    public String getQuestion() {
        return question;
    }
    public int getTypeOfRightAnswers() {
        return typeOfRightAnswers;
    }

    public void setAnswers(ArrayList<String> answers) {
        this.answers = answers;
    }
    public void setTypeOfRightAnswers(int typeOfRightAnswers) {
        this.typeOfRightAnswers = typeOfRightAnswers;
    }
    public void setRightAnswers(char rightAnswers) {
        this.rightAnswers = rightAnswers;
    }
    public void setQuestion(String question) {
        this.question = question;
    }

}



