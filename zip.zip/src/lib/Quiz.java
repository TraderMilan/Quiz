package lib;

import java.util.ArrayList;

public class Quiz {
    private ArrayList<Questions> listOfQuestions = new ArrayList<>();

    public Quiz(ArrayList<Questions> listOfQuestions) {
        this.listOfQuestions = listOfQuestions;
    }


    public void addQuestion (Questions question){
    listOfQuestions.add(question);
    }

    public void printQuestion (Questions question){


    }
}
