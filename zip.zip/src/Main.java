import lib.Questions;
import lib.Quiz;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        ArrayList<String> answers1 = new ArrayList<String>();
        answers1.add("a) 12"+ "b) 16" + "c) 64");
        ArrayList<String> answers2 = new ArrayList<String>();
        answers1.add("a) 25"+ "b) 15" + "c) 50");
        ArrayList<String> answers3 = new ArrayList<String>();
        answers1.add("a) 2"+ "b) 8" + "c) 4");


        Questions question1 = new Questions("Kolko je 4^3? ", 'c', 1, answers1);
        Questions question2 = new Questions("Kolko je 5*5? ", 'a', 1, answers2);
        Questions question3 = new Questions("8 krat kolko je 64? ", 'b', 1, answers3);

        ArrayList <Questions> listOfQuestions = new ArrayList<>();
        listOfQuestions.add(question1);
        listOfQuestions.add(question2);
        listOfQuestions.add(question3);

        Quiz quiz = new Quiz(listOfQuestions);


        System.out.println("Welcome to Math Quiz! ");
        System.out.println("Can you solve these 3 questions? ");

        System.out.println();



    }
}